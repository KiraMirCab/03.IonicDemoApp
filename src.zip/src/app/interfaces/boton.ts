export interface Boton {
    nombre: string,
    numero: number,
    color: string
}
